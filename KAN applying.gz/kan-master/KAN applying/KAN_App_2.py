import flet as ft
import json
import os
import torch
import numpy as np
from scipy.interpolate import interp1d
from kan import MultKAN
from pathlib import Path

# -----------------------------
# 1. Классы и функции модели
# -----------------------------
class_mapping = {"воздух": 0, "вода": 1, "сок": 2, "молоко": 3, "квас": 4, "масло": 5}
inv_class_mapping = {v: k for k, v in class_mapping.items()}

def predict_signal(model, signal, target_length=65):
    """Предсказание класса для одного сигнала."""
    x_old = np.linspace(0, 1, len(signal))
    x_new = np.linspace(0, 1, target_length)
    f = interp1d(x_old, signal, kind="linear")
    signal_interp = f(x_new)

    # Нормализация
    min_val = signal_interp.min()
    max_val = signal_interp.max()
    signal_norm = (signal_interp - min_val) / (max_val - min_val + 1e-8)

    signal_tensor = torch.tensor(signal_norm, dtype=torch.float32).unsqueeze(0)
    model.eval()
    with torch.no_grad():
        output = model(signal_tensor)
        pred_class_idx = output.argmax(dim=1).item()

    return inv_class_mapping[pred_class_idx]

# -----------------------------
# 2. Загрузка модели
# -----------------------------
def load_model():
    script_dir = Path(__file__).parent if "__file__" in globals() else Path.cwd()
    checkpoint_dir = script_dir / "model_2"
    # checkpoint_dir = r"D:/PROGRAMS/KANmodel_2"  # путь к модели
    model_filename = "model_2.pth"
    full_path = os.path.join(checkpoint_dir, model_filename)

    target_length = 65
    num_classes = 6
    width = [target_length, 64, num_classes]

    model = MultKAN(width=width)
    checkpoint = torch.load(full_path, map_location="cpu")
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model

# -----------------------------
# 3. Интерфейс Flet
# -----------------------------
def main(page: ft.Page):
    page.title = "Анализатор сигналов (KAN)"
    page.scroll = "auto"
    page.vertical_alignment = "center"
    page.horizontal_alignment = "center"

    # --- Загружаем модель при старте ---
    try:
        model = load_model()
        model_status = ft.Text("✅ Модель успешно загружена", color="green")
    except Exception as e:
        model = None
        model_status = ft.Text(f"❌ Ошибка загрузки модели: {e}", color="red")

    # Элементы интерфейса
    selected_file = ft.Text("", selectable=True)
    result_output = ft.Text("", selectable=True)
    amplitudes_output = ft.Text("", selectable=True)
    num_output = ft.Text("", selectable=True)
    predict_output = ft.Text("", selectable=True, size=18, weight="bold", color="blue")

    file_path = None
    amplitudes = []

    # --- Обработка данных ---
    def process_data(e):
        nonlocal file_path, amplitudes

        if not file_path:
            result_output.value = "⚠️ Сначала выберите файл!"
            page.update()
            return

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            amplitudes = [item["Amplitude"] for item in data if "Amplitude" in item]
            num_measurements = len(amplitudes)

            result_output.value = f"✅ Файл успешно обработан"
            amplitudes_output.value = f"📈 Амплитуды: {amplitudes[:10]}... ({len(amplitudes)} значений)"
            num_output.value = f"🔢 Количество измерений: {num_measurements}"

            # Если модель загружена — анализируем
            if model and len(amplitudes) > 0:
                predicted_class = predict_signal(model, amplitudes)
                predict_output.value = f"🧠 Определено вещество: {predicted_class}"
            else:
                predict_output.value = "⚠️ Модель не загружена или нет данных!"

        except Exception as ex:
            result_output.value = f"❌ Ошибка при обработке: {ex}"
            amplitudes_output.value = ""
            num_output.value = ""
            predict_output.value = ""

        page.update()

    # --- После выбора файла ---
    def open_file_result(e: ft.FilePickerResultEvent):
        nonlocal file_path
        if not e.files:
            return
        file_path = e.files[0].path
        selected_file.value = f"📄 Выбран файл: {file_path}"
        process_button.visible = True
        page.update()

    # --- Диалог выбора файла ---
    file_picker = ft.FilePicker(on_result=open_file_result)
    page.overlay.append(file_picker)

    open_button = ft.ElevatedButton(
        "Выбрать JSON-файл",
        icon=ft.icons.FILE_OPEN,
        on_click=lambda _: file_picker.pick_files(
            allow_multiple=False, allowed_extensions=["json"]
        ),
    )

    process_button = ft.ElevatedButton(
        "Обработать и проанализировать",
        icon=ft.icons.PLAY_ARROW,
        on_click=process_data,
        visible=False,
    )

    layout = ft.Column(
        [
            ft.Text("📊 Анализ жидкостей по методу KAN", size=22, weight="bold"),
            model_status,
            open_button,
            process_button,
            selected_file,
            result_output,
            amplitudes_output,
            num_output,
            predict_output,
        ],
        spacing=15,
        alignment="center",
        horizontal_alignment="center",
    )

    page.add(layout)

# -----------------------------
# Запуск
# -----------------------------
if __name__ == "__main__":
    ft.app(target=main)
